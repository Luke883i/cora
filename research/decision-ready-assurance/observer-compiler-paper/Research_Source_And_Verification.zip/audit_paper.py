#!/usr/bin/env python3
"""Finite author-scoped OOXML/package and source-register checks.
Does not rerun target products or independently validate all source claims.
"""
from pathlib import Path
import io,zipfile,json,hashlib,re,collections,xml.etree.ElementTree as ET
from docx import Document
R=Path(__file__).resolve().parent
P=R/'From_Intent_to_Evidence.docx'
S=json.loads((R/'Gold_Git_Witnesses_120.json').read_text())
A=S['selection']
Q=json.loads((R/'Adversarial_Questions_1000.json').read_text())['questions']
C=json.loads((R/'Adversarial_Core_100.json').read_text())['questions']
MS=[
 'it does not replace expert acceptance',
 'no algebraic lattice structure or mathematical completeness theorem is claimed',
 'not a claim of formal derivation',
 'cannot be reduced to compilation',
 'not proof that no undiscovered failures exist',
 'It does not prove that theory generated each product',
 'not a claim that every item is legally required',
 'are generated inspection prompts, not 1,000 expert interviews',
 'A ZIP lacks the complete Git object history',
 'AOSP (Augmented Ontological-Semantic Platforms) names an ecosystem',
 'real-versus-synthetic blind test remains outstanding',
 'not already proved',
 'CORA may lower the expertise needed to ORCHESTRATE',
 'A checklist does not supply the expertise',
 'can emit structured candidate states',
 'hashes nor signatures certify',
 'these are NOT product executions or independent science',
]
# Normalized semantic phrases must each appear at least once in reader text.

sha=lambda b:hashlib.sha256(b).hexdigest()

def zip_change(original,path,old,new):
    out=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(original),'r') as src,zipfile.ZipFile(out,'w') as target:
        for item in src.infolist():
            payload=src.read(item.filename)
            if item.filename==path:
                if isinstance(old,str): old=old.encode()
                if isinstance(new,str): new=new.encode()
                if old not in payload: raise AssertionError(f'NOT_FOUND {path}: {old[:100]}')
                payload=payload.replace(old,new,1)
            info=zipfile.ZipInfo(item.filename,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o600<<16;info.create_system=3
            target.writestr(info,payload,compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
    return out.getvalue()

def links(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        root=ET.fromstring(z.read('word/_rels/document.xml.rels'))
    return [v.attrib['Target'] for v in root if v.attrib.get('Type','').endswith('/hyperlink')]

def wordtext(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:xml=z.read('word/document.xml')
    root=ET.fromstring(xml)
    # collect exact paragraph-level text, preserving runs and hyperlink spans.
    return '\n'.join(''.join(x.text or '' for x in para.iter() if x.tag.endswith('}t')) for para in root.iter() if para.tag.endswith('}p'))

def image_alt(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:xml=z.read('word/document.xml')
    root=ET.fromstring(xml)
    return [x.attrib.get('descr','') for x in root.iter() if x.tag.endswith('}docPr')]

def critique(data,expected_urls):
    findings=[]
    ls=links(data)
    if len(ls)!=136 or sorted(ls)!=sorted(expected_urls):findings.append('LINK_PINS_OR_STANDARDS_DRIFT')
    body=wordtext(data)
    visible=body.lower()
    for token in ('academics','evria','derive all indispensable conditions','independent counterexamples','the earlier version of this paper','prior draft of this paper'):
        if token in visible:findings.append('FORBIDDEN_READER_WORD_'+token)
    for frag in MS:
        if frag.lower() not in visible:findings.append('CRITICAL_CLAIM_REMOVED_'+frag[:33])
    for name in ('ICTC','Teddy','LUMEN','NILO','iKant_EDU','CORA'):
        if name+'  |  Product, software and repository' not in body:findings.append('MISSING_PRODUCT_HEADING_'+name)
    if len(image_alt(data))!=4 or any(not x for x in image_alt(data)):findings.append('INACCESSIBLE_FIGURE_ALT')
    return findings

def main():
    assert len(A)==120 and len(Q)==1000 and len(C)==100
    bypair=collections.Counter((x['repository'],x['lens']) for x in A)
    assert len(bypair)==24 and set(bypair.values())=={5}
    assert len({(x['repository'],x['sha']) for x in A})==120
    assert all(re.fullmatch('[0-9a-f]{40}',x['sha']) and re.fullmatch('[0-9a-f]{40}',x['blob']) for x in A)
    assert len({x['id'] for x in Q})==1000
    expected_source=[x['url'] for x in A]
    expected_standard=['https://www.iso.org/standard/72089.html','https://www.iso.org/standard/81702.html','https://www.iso.org/standard/78176.html',
      'https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final','https://csrc.nist.gov/pubs/sp/800/218/final','https://asvs.owasp.org/',
      'https://slsa.dev/spec/v1.2/','https://csrc.nist.gov/Projects/automated-combinatorial-testing-for-software/faqs']
    expected_roa=[
 'https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/annex-b-rla-biological-case-bryophyte.md',
 'https://github.com/Luke883i/ROA/blob/b0dcda8bef8b6e34455d86907db56f29ead1c521/Reticular%20Local%20Abstraction%20RLA-CRC-ECNN/ROA%20Bryophyte%20Epistemic%20Lab/ROA_Bryophyte_Epistemic_Lab_v9.html',
 'https://github.com/Luke883i/ROA/blob/b0dcda8bef8b6e34455d86907db56f29ead1c521/Reticular%20Local%20Abstraction%20RLA-CRC-ECNN/ROA%20Bryophyte%20Epistemic%20Lab/ROA_Bryophyte_Epistemic_Lab_README.md',
 'https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/annex-a-rla-crc-foundations.md',
 'https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/annex-c-ecnn-formalisation.md',
 'https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/observer-compiler-wolfram.md',
 'https://github.com/Luke883i/ROA/commit/b0dcda8bef8b6e34455d86907db56f29ead1c521'
 ]
    expected=expected_source+expected_standard+expected_roa+['https://www.nist.gov/programs-projects/combinatorial-testing']
    raw=P.read_bytes();findings=critique(raw,expected)
    assert not findings,findings
    test=[];seen=set();hist={}
    def run(label,mutant,classification):
        digest=sha(mutant);assert digest not in seen,(label,'DUPLICATE_MUTANT');seen.add(digest)
        found=critique(mutant,expected)
        test.append({'id':label,'family':classification,'mutant_sha256':digest,'caught':bool(found),'first_finding':found[0] if found else None})
    for i,url in enumerate(expected_source,1):
        new=url.replace('github.com/Luke883i/','github.com/irrelevant-other-owner/',1)
        run(f'LINK_{i:03}',zip_change(raw,'word/_rels/document.xml.rels',url,new),'original-Git-link')
    # Change critical, authored claim strings in full package, not merely grep source script.
    for i,frag in enumerate(MS,1):
        run(f'CLAIM_{i:02}',zip_change(raw,'word/document.xml',frag,'Universal author-certified correctness granted'),'material-claim')
    # Six physically rewritten product occurrences, identity not hidden in other case sections.
    sourcexml=zipfile.ZipFile(io.BytesIO(raw)).read('word/document.xml').decode()
    for name in ('ICTC','Teddy','LUMEN','NILO','iKant_EDU','CORA'):
        # Mutation of the introductory instance of the name requires original literal text in XML.
        old='<w:t>'+name+'  |  Product, software and repository</w:t>';assert old in sourcexml,name
        run('PRODUCT_'+name,zip_change(raw,'word/document.xml',old,'<w:t>Unspecified product and repository</w:t>'),'product-identity')
    # Remove each figure's precise alternative text.
    descriptions=image_alt(raw)
    for i,a in enumerate(descriptions,1):
        run(f'ALT_{i}',zip_change(raw,'word/document.xml','descr="'+a+'"','descr=""'),'image-alternative')
    assert len(test)==120+len(MS)+6+4,(len(test),collections.Counter(x['family'] for x in test))
    # Ten physically rewritten copies with benign metadata variations: semantics remain intact.
    benign=[]
    with zipfile.ZipFile(io.BytesIO(raw)) as z:core=z.read('docProps/core.xml').decode()
    marker=re.search(r'<dc:creator[^>]*>.*?</dc:creator>',core)
    assert marker, 'creator core props not found'
    old=marker.group()
    for i in range(10):
        mut=zip_change(raw,'docProps/core.xml',old,f'<dc:creator>Neutral renderer {i}</dc:creator>')
        benign.append(not critique(mut,expected))
    expected_count={'original-Git-link':120,'material-claim':len(MS),'product-identity':6,'image-alternative':4}
    assert dict(collections.Counter(x['family'] for x in test))==expected_count
    result={
     'status':'PASS_AUTHOR_SCOPED' if all(x['caught'] for x in test) and all(benign) else 'FAIL',
     'document_sha256':sha(raw),'document_bytes':len(raw),
     'selected_Git_pins':120,'selected_per_repository':20,'selected_per_repository_per_lens':5,
     'direct_topic_fit':sum(x['semantic_fit']=='topic-addressed' for x in A),
     'adjacent_inquiry':sum('adjacent inquiry' in x['semantic_fit'] for x in A),
     'original_source_hyperlinks':120,'official_standard_links':9,'scientific_case_links':len(expected_roa),'diagrams':4,
     'adversarial_question_templates':100,'adversarial_questions_unexecuted':1000,
     'physical_modified_Word_variants':len(test),'physical_negative_detected':sum(x['caught'] for x in test),
     'distinct_mutant_sha256':len(seen),'survivors':[x['id'] for x in test if not x['caught']],
     'benign_metadata_mutants':10,'benign_accepted':sum(benign),
     'author_oracle':'FINITE_EXACT_LINKS_AUTHOR_DEFINED_CLAIM_ANCHORS_PROJECT_LABELS_IMAGE_ALT',
     'original_repo_runtime':'NOT_RERUN','capacity_benchmark':'NOT_PERFORMED','human_test':'NOT_PERFORMED','independent_security_audit':'NOT_PERFORMED',
     'tests':test}
    (R/'Document_Adversarial_Audit.json').write_text(json.dumps(result,indent=2)+'\n')
    assert result['status']=='PASS_AUTHOR_SCOPED',result
    print(json.dumps({k:v for k,v in result.items() if k!='tests'},indent=2))
if __name__=='__main__':main()
