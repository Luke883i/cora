#!/usr/bin/env python3
"""Author-scoped falsifiable, bounded semantic-contract study, without target-runtime claims."""
from pathlib import Path
from collections import Counter
import hashlib, json, random, re
ROOT=Path(__file__).parent
DIMENSIONS=[
 ('observer_horizon','Which observer, questions and excluded conditions delimit the claimed result?'),
 ('abstraction_transfer','What conceptual distinctions are lost, invented or renamed across levels?'),
 ('expertise_leverage','Does a novice actually need less expert intervention to reach an accepted result?'),
 ('product_software_repo','Do product experience, executable behavior and Git history claim separate authority?'),
 ('engineering_contract','Which candidate necessary leaf has a failure condition and an accountable owner?'),
 ('counterexample_independence','Is the negative oracle independently specified or merely author-consistent?'),
 ('capacity_scaling','Which user, workload, concurrency and resource envelopes are genuinely measured?'),
 ('security_and_crypto','Is authorization, failure visibility, origin, digest and issuer identity separated?'),
 ('provenance_replay','Can an outsider replay exact code, environment, evidence and decision?'),
 ('empirical_science','How would blinded real-versus-synthetic expert measurement refute a hypothesis?')]
LENSES=[
 ('source','exact source or file identity'),('implementation','code and control execution'),
 ('runtime','native running outcome'),('counterfactual','typed adversarial counterexample'),
 ('human','human operator effort and comprehension'),('cost','economic and computation cost'),
 ('governance','authority and permission'),('security','confidentiality and integrity'),
 ('time','longitudinal recovery and change'),('external','independent field acceptance')]
NODELIST=[]
for i,(dim,dq) in enumerate(DIMENSIONS):
 for j,(lens,focus) in enumerate(LENSES):
  NODELIST.append({'id':f'SCI-{i*10+j+1:03d}','dimension':dim,'lens':lens,
                   'question':f'{dq} Check specifically {focus}.',
                   'evidence_state':'HYPOTHESIS_NOT_INDEPENDENTLY_EVALUATED',
                   'oracle_owner':'REQUIRES_DOMAIN_APPROPRIATE_EXTERNAL_ORIGINAL_ORACLE',
                   'acceptance':'DO_NOT_PROMOTE_FROM_SAMPLED_SOURCE_TO_EXTERNAL_TRUTH'})
assert len(NODELIST)==100 and len({x['id'] for x in NODELIST})==100
(BASE:=ROOT/'Scientific_Challenge_Nodes_100.json').write_text(json.dumps({'schema':'cora-paper-scientific-nodes/1','status':'PROPOSED_CHALLENGES_NOT_EVALUATED','nodes':NODELIST},indent=2)+'\n')
orig=json.loads(BASE.read_text());base_bytes=BASE.read_bytes();base_sha=hashlib.sha256(base_bytes).hexdigest()
# Model-level source mutation regimes are actual edited JSON objects in memory. No executable code or external systems.
CATS=('promote_evidence','forge_authority','erase_horizon','rewrite_question','alter_scope','invert_acceptance','delete_node','duplicate_node','misstate_oracle','replace_dimension')
seed=13072026; rng=random.Random(seed);records=[];seen=set();counts=Counter();surv=[]
for k in range(10_000):
 idx=k%100;category=CATS[(k//100)%10]
 clone={'schema':orig['schema'],'status':orig['status'],'nodes':[dict(n) for n in NODELIST]}
 node=clone['nodes'][idx]
 partner=(idx+1+(k//100))%100
 clone['nodes'][partner]['question'] += ' Counterfactual axis: ' + NODELIST[(k//100)%100]['lens'] + '/' + str(k//100)
 if category=='promote_evidence':node['evidence_state']='EMPIRICALLY_VERIFIED'
 if category=='forge_authority':node['oracle_owner']='SELF_APPROVED_BY_AGENT'
 if category=='erase_horizon':node['acceptance']='ANY_SCENARIO_COUNTS_AS_PASS'
 if category=='rewrite_question':node['question']='This is proven universally.'
 if category=='alter_scope':node['lens']='out_of_scope_'+str(k)
 if category=='invert_acceptance':node['acceptance']='SOURCE_IMPLIES_GLOBAL_APPROVAL'
 if category=='delete_node':clone['nodes'].pop(idx)
 if category=='duplicate_node':clone['nodes'].append(dict(node))
 if category=='misstate_oracle':node['oracle_owner']='NO_INDEPENDENT_ORACLE_REQUIRED'
 if category=='replace_dimension':node['dimension']='UNSPECIFIED'
 raw=(json.dumps(clone,sort_keys=True,separators=(',',':'))+'\n').encode()
 h=hashlib.sha256(raw).hexdigest();assert h not in seen;seen.add(h)
 # The independent (relative to mutation selection) typed validation uses a frozen reference of node semantics.
 valid=len(clone['nodes'])==100 and len({x['id'] for x in clone['nodes']})==100
 if valid:
  n=clone['nodes'][idx]
  valid=n==NODELIST[idx] and all(x['evidence_state']=='HYPOTHESIS_NOT_INDEPENDENTLY_EVALUATED' for x in clone['nodes'])
 killed=not valid
 if not killed:surv.append(k)
 counts[category]+=int(killed)
 records.append({'id':f'V{k+1:05d}','seed':seed,'node_id':node['id'],'fault_family':category,'edited_json_sha256':h,'expected':'KILLED','observed':'KILLED' if killed else 'SURVIVED','oracle':'TYPED_FROZEN_REFERENCE','model_only':True})
benign=[]
for j in range(10):
 # Reader-invisible metadata in a separate envelope is allowed by schema; node data unchanged.
 envelope={'metadata':{'rendering_label':f'neutral-label-{j}'},'schema':orig['schema'],'status':orig['status'],'nodes':NODELIST}
 benign.append(envelope['nodes']==NODELIST and envelope['status']==orig['status'])
summary={'schema':'cora-paper-bounded-model-mutation/1','source_sha256':base_sha,'seed':seed,
         'model_variants_constructed':len(records),'distinct_edited_json_sha256':len(seen),
         'fault_families':CATS,'detected_by_typed_oracle':sum(counts.values()),'survivors':surv,
         'benign_controls':10,'benign_accepted':sum(benign),
         'scope':'AUTHOR_DEFINED_STRUCTURAL_MODEL_NEGATIVES_NOT_PRODUCT_RUNTIME_OR_EXTERNAL_HUMAN_EVIDENCE',
         'original_bryophyte_empirical_validation':'NOT_DONE','scientific_nodes_evaluated_by_independent_experts':0}
(ROOT/'Mutation_Manifest_10000.json').write_text(json.dumps({'summary':summary,'mutations':records},separators=(',',':'))+'\n')
(ROOT/'Scientific_Challenge_Audit.json').write_text(json.dumps(summary,indent=2)+'\n')
assert len(seen)==10000 and not surv and all(benign)
print(json.dumps({k:v for k,v in summary.items() if k not in ('fault_families','survivors')},indent=2))
