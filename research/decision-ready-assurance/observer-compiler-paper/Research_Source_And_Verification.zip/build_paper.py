#!/usr/bin/env python3
"""Build a standalone public engineering paper from a bounded original-Git witness registry.
No external runtime, approval, or human acceptance is implied by this build.
"""
from pathlib import Path
import json, hashlib, io, zipfile, re, math, textwrap, collections
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches, Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).parent
DATA=ROOT/'Gold_Git_Witnesses_120.json'
DOC=ROOT/'From_Intent_to_Evidence.docx'
SEED=json.loads(DATA.read_text())
EVIDENCE=SEED['selection']
REPOS=['ictc','teddy','lumen','NILO','iKant_EDU','cora']
NAMES={'ictc':'ICTC','teddy':'Teddy','lumen':'LUMEN','NILO':'NILO','iKant_EDU':'iKant_EDU','cora':'CORA'}
NAVY='#102B40'; INK='#1B3041'; SOFT='#506C7E'; TEAL='#087E77'; PAPER='#F7F8F6'; LIGHT='#E8F3F1'; BORDER='#D7E1E7'; WARM='#F4EFE7'; WHITE='#FFFFFF'
FF='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';FB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
HEADS={'ictc':('633ce78e8cbe409f8be6e7779da08832c1a237d7',1440,53,9338970),
 'teddy':('baadd6e69a0ccaec83fc6fc8659850d7b863b80e',362,25,1487056),
 'lumen':('547e46788e72f1556dc2e32db3621d008032cbd0',157,7,1052797),
 'NILO':('3513ead1cf82dd104d471e20cfc9b11bf81158fb',57,3,392303),
 'iKant_EDU':('e270c6e2cc772f960126eecea9f50501339e3656',1645,116,9495206),
 'cora':('2e0c1f9d0cbaf575f9430fabbff94a787187da58',316,14,3640726)}
STANDARDS=[
 ('ISO/IEC/IEEE 29148:2018 — requirements engineering','https://www.iso.org/standard/72089.html'),
 ('ISO/IEC/IEEE 15288:2023 — system life cycle','https://www.iso.org/standard/81702.html'),
 ('ISO/IEC 25010:2023 — product quality','https://www.iso.org/standard/78176.html'),
 ('NIST SP 800-160 Vol. 1 Rev. 1 — trustworthy systems','https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final'),
 ('NIST SSDF SP 800-218 — secure development','https://csrc.nist.gov/pubs/sp/800/218/final'),
 ('OWASP ASVS 5.0.0 — web application security','https://asvs.owasp.org/'),
 ('SLSA v1.2 — software supply-chain provenance','https://slsa.dev/spec/v1.2/'),
 ('NIST combinatorial testing — bounded interaction coverage','https://csrc.nist.gov/Projects/automated-combinatorial-testing-for-software/faqs')]
PRODUCTS={
'ictc':{
 'noun':'Compliance knowledge and review workflows',
 'architecture':'A Node.js HTTP service, policy and role-sensitive handlers, SQLite records and audit receipts, and browser views for seven procedural workflows. The software separates source/requirement descriptions from attributable human action and decision.',
 'observable':'Browser-inspector repairs, differentiated role journeys, provenance freshness and same-database restart tests are represented in the Git record.',
 'enterprise':'Relative to a hypothetical governed compliance service, production identity, operations, verified access-denial paths, security review, resilience and legal acceptance require independently scoped evidence. Its code and test density are not a legal compliance certificate.',
 'contraction':'SELECTIVE, STARTED — User-interface and assurance convergence is evident; no safe whole-repository retirement of consumers is established. Quantify overlapping writers, workflow responsibility and hidden UI owners before a further cut.',
 'experiment':'Map all record writers and viewer consumers; deliberately remove a disposable role guard and prove that the native HTTP/SQLite oracle discriminates, then exercise restart/readback and browser effects on one source revision.'},
 'teddy':{
 'noun':'Local conversation and articulated three-dimensional character',
 'architecture':'A Node.js control plane, SQLite history, a local language-model option and explicitly selected external providers, browser conversation controls and a WebGL movement/skin rig. Model selection, request provenance and character motion are separate contracts.',
 'observable':'Origin and anti-forgery repairs, one-time recovery of rotated request tokens, bounded context chronology, motion geometry tests and real-browser capture source are present.',
 'enterprise':'A typical supported interactive service would quantify inference throughput, CPU/GPU memory, client diversity, abuse and provider error budgets, secrets/availability, latency and visual usability. Pose tests alone cannot validate charm or service reliability.',
 'contraction':'SELECTIVE, STARTED — Startup unification and locally bounded motion/control changes exist. Potential duplication spans launch paths, movement oracles and provider test adapters; a large contraction is not yet justified.',
 'experiment':'Replay local and provider-authentic turn paths separately, rotate anti-forgery proofs, abort a request, and compare original gestures and layout under named browsers; instrument resource envelopes before merging owners.'},
 'lumen':{
 'noun':'Role-aware library operations with offline web access',
 'architecture':'Node.js web/API service with local SQLite loans, accounts and receipts; a progressive web app uses browser CacheStorage. Optional Koha and institutional sign-on adapters remain different authorities.',
 'observable':'Cache-write quota failure, online revalidation, backup metadata/permissions, production-start preflight and browser update behavior have source changes and scoped tests.',
 'enterprise':'A hypothetical institutional library would require effective single-sign-on/Koha integration, restore drills, load and session isolation, availability, privacy/security approval and physical-device acceptance. A single persistent SQLite instance is not high availability.',
 'contraction':'NOT INDICATED AS GLOBAL PRIORITY — Compact code and workflow footprint; no evidence-based need for radical restructuring. Measure any repetitive adapter or runbook logic before a local consolidation.',
 'experiment':'Run a mixed workload of reads/writes by role, induce cache failure and interrupted persistence, restore an actual backup, and measure capacity and errors under the intended deployment topology.'},
 'NILO':{
 'noun':'Original browser-based narrative platform game',
 'architecture':'A small static Canvas2D/game-state source, collision and player controls, level modules, checkpoint persistence and a deterministic static build. Three candidate levels and one candidate boss exist; the intended game is broader.',
 'observable':'Physical route/physics mutants, browser level transitions, checkpoint restart safeguards, asset integrity and delivery contracts exist in source.',
 'enterprise':'The appropriate commercial-grade comparison is stable frame timing, device/browser compatibility, accessible controls where required, artwork rights, crash recovery, packaging and independent playtesting—not multi-tenant authorization for a single-player prototype.',
 'contraction':'NOT INDICATED — The implementation is small. Expanding playable scope while retaining one physics/render path matters more than reducing directories; watch for duplicated per-level rules as new chapters are built.',
 'experiment':'Measure frame-time distributions and input latency across device classes; inject invalid checkpoints and stale asset builds; ask independent players to complete levels without developer guidance.'},
 'iKant_EDU':{
 'noun':'Experimental language-model interaction controller',
 'architecture':'Session-chat and external Model Context Protocol/server surfaces reuse bounded controller primitives but have distinct host, session, authorization and transport obligations. A replaceable language model is not itself the source of operational authority.',
 'observable':'A physical fifteen-to-seven-root restructuring is recorded with exact blob/mode comparisons, historic epoch recovery and multiple corrective workflow/source-receipt steps.',
 'enterprise':'A production host-bound controller would require independent host admission, consent and authorization, reliable session/tenant separation, dynamic-consumer closure, durable evidence, incident handling and effective branch/release controls. A source check cannot attest a real host callback.',
 'contraction':'RADICAL PHYSICAL CUT EXECUTED; GLOBAL EQUIVALENCE OPEN — Seven top-level roots do not resolve 116 workflows, dynamic clients and historical references. Further deletion is blocked until consumer-preserving parity is witnessed.',
 'experiment':'Census all static and dynamic imports, host and environment paths; verify the old historical snapshots independently; replay genuine host sessions and MCP readback on the candidate SHA before retiring an owner.'},
 'cora':{
 'noun':'Local source-assurance method and executable engine',
 'architecture':'A Python 3.11+ command-line engine for exact-Git source inspection, artifact roles, dependency and claim analysis, bounded falsification and one-run evidence dossiers. The method can guide an agent; the engine does not become that agent or a release approver.',
 'observable':'Git-history replay, editorial mutation controls, structured comparative null findings and consolidation of forensic inspection inside the existing one-run path are traceable.',
 'enterprise':'An enterprise assurance service would additionally establish parser coverage, repeatable result integrity, independent oracles, security/supply-chain assurances, protected release rules, reviewer identity, interoperability, support and incremental human benefit.',
 'contraction':'EVALUATE SELECTIVELY — Recent origin is not evidence that every layer is needed. With 64 package modules, 14 workflows and a broad command catalog, overlap should be measured before any net-reduction target; some local workflow/profile consolidation has begun.',
 'experiment':'Profile command-to-owner and verifier overlap, replay native CLI fixtures and original Git mutants on the same revision; compare cost and false acceptance against a strong non-CORA checklist.'}}

def color(x):return RGBColor.from_string(x.lstrip('#'))
def font(size,bold=False):return ImageFont.truetype(FB if bold else FF,size)
def multi(draw,xy,s,width,sz=21,bold=False,fill=INK,center=True):
 f=font(sz,bold); lines=[];line=''
 for w in s.split():
  y=(line+' '+w).strip()
  if draw.textbbox((0,0),y,font=f)[2]>width and line:lines.append(line);line=w
  else:line=y
 if line:lines.append(line)
 x,y=xy
 for i,ln in enumerate(lines):
  bw=draw.textbbox((0,0),ln,font=f)[2];draw.text((x+(width-bw)/2 if center else x,y+i*(sz+7)),ln,font=f,fill=fill)
 return len(lines)*(sz+7)
def box(draw,rect,fill=LIGHT,outline=BORDER):draw.rounded_rectangle(rect,radius=18,fill=fill,outline=outline,width=3)
def figure1():
 im=Image.new('RGB',(1700,400),WHITE);d=ImageDraw.Draw(im)
 steps=[('Human result','Value + boundaries'),('Engineering contract','Necessary known obligations'),('Semantic reticulum','Typed relations + unknowns'),('Run & challenge','Native behavior + fault models'),('Accountable decision','Accept narrowly / revise')]
 for i,(title,sub) in enumerate(steps):
  x=22+i*339;box(d,(x,96,x+306,288),LIGHT if i%2==0 else WARM)
  multi(d,(x+16,135),title,275,24,True,NAVY)
  multi(d,(x+14,198),sub,278,19,False,INK)
  if i<4:d.line((x+305,193,x+337,193),fill=TEAL,width=5);d.polygon([(x+330,184),(x+341,193),(x+330,202)],fill=TEAL)
 d.text((31,30),'One continuously revisable contract, never a one-click certificate',font=font(28,True),fill=NAVY)
 d.text((280,336),'Observed failures, changed assumptions and new consumers reopen the graph.',font=font(22,True),fill=TEAL)
 im.save(ROOT/'figure_contract.png')
def figure2():
 im=Image.new('RGB',(1730,610),WHITE);d=ImageDraw.Draw(im)
 d.text((38,22),'Typed semantic reticulum: several useful projections, no magic completeness',font=font(27,True),fill=NAVY)
 nodes=[('Human outcome',(90,150),'#E8F3F1'),('Necessary obligation',(600,111),'#F4EFE7'),('Owner / authority',(1110,150),'#E8F3F1'),('Implementation',(300,365),'#F4EFE7'),('Observed execution',(825,355),'#E8F3F1'),('Unknown consumer',(1350,370),'#F4EFE7')]
 edges=[(0,1,'requires'),(1,2,'owned by'),(1,3,'realized by'),(3,4,'tested on'),(4,5,'does not close')]
 centers=[]
 for s,(x,y),fill in nodes:centers.append((x+180,y+57))
 for a,b,t in edges:
  d.line([centers[a],centers[b]],fill=TEAL,width=5)
  cx=(centers[a][0]+centers[b][0])//2;cy=(centers[a][1]+centers[b][1])//2
  d.rectangle((cx-70,cy-13,cx+70,cy+18),fill=WHITE)
  multi(d,(cx-69,cy-10),t,138,17,True,SOFT)
 for s,(x,y),fill in nodes:box(d,(x,y,x+360,y+113),fill);multi(d,(x+12,y+35),s,336,22,True,NAVY)
 d.text((36,545),'A dependency DAG is one projection. Provenance, contradiction, permission and time are others.',font=font(21),fill=SOFT)
 im.save(ROOT/'figure_reticulum.png')
def figure3():
 im=Image.new('RGB',(1690,460),WHITE);d=ImageDraw.Draw(im)
 d.text((36,22),'The AI inspects a bounded scenario space; production remains a separate witness',font=font(27,True),fill=NAVY)
 labels=[('Population','roles × sessions × demand'),('Security','actor × action × resource'),('Continuity','failure × state × recovery'),('Delivery','revision × host × journey')]
 for i,(a,b) in enumerate(labels):
  x=34+i*417;box(d,(x,100,x+386,267),WARM if i%2 else LIGHT)
  multi(d,(x+10,139),a,365,25,True,NAVY)
  multi(d,(x+10,204),b,365,19,False,INK)
 d.line((190,322,1490,322),fill=TEAL,width=6)
 d.polygon([(1490,311),(1510,322),(1490,333)],fill=TEAL)
 d.text((385,348),'Model → select risk cases → execute native tests → keep survivors',font=font(23,True),fill=TEAL)
 im.save(ROOT/'figure_cartesian.png')
def figure4():
 im=Image.new('RGB',(1660,380),WHITE);d=ImageDraw.Draw(im)
 d.text((30,25),'Contraction must improve ownership cost without deleting observable responsibility',font=font(26,True),fill=NAVY)
 labels=[('Duplicate cost?','Measure owner/time'),('Consumers known?','Include dynamic & external'),('Parity witnessed?','Original checks + runtime'),('Rollback viable?','Preserve Git epochs')]
 for i,(h,s) in enumerate(labels):
  x=38+i*414;box(d,(x,104,x+385,263),LIGHT if i%2==0 else WARM)
  multi(d,(x+10,134),h,360,23,True,NAVY)
  multi(d,(x+12,195),s,360,19,False,INK)
  if i<3:d.line((x+386,183,x+410,183),fill=TEAL,width=5)
 d.text((192,310),'Any unknown mandatory consumer or lost authority blocks retirement.',font=font(25,True),fill=TEAL)
 im.save(ROOT/'figure_contraction.png')
for f in [figure1,figure2,figure3,figure4]:f()

def shade(cell,hexcolor):
 pr=cell._tc.get_or_add_tcPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),hexcolor.lstrip('#'));pr.append(sh)
def no_split(row):row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
def headerrow(row):
 e=OxmlElement('w:tblHeader');e.set(qn('w:val'),'true');row._tr.get_or_add_trPr().append(e)
def link(p,txt,url):
 part=p.part;rid=part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
 el=OxmlElement('w:hyperlink');el.set(qn('r:id'),rid);r=OxmlElement('w:r');rp=OxmlElement('w:rPr');cl=OxmlElement('w:color');cl.set(qn('w:val'),TEAL.lstrip('#'));rp.append(cl);un=OxmlElement('w:u');un.set(qn('w:val'),'single');rp.append(un);r.append(rp);t=OxmlElement('w:t');t.text=txt;r.append(t);el.append(r);p._p.append(el)

def ensure_doc():
 d=Document(); sec=d.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7)
 sec.top_margin=Cm(1.72);sec.bottom_margin=Cm(1.55);sec.left_margin=Cm(2.12);sec.right_margin=Cm(2.12);sec.header_distance=Cm(.78);sec.footer_distance=Cm(.78)
 st=d.styles['Normal'];st.font.name='Aptos';st.font.size=Pt(9.2);st.font.color.rgb=color(INK);st.paragraph_format.space_after=Pt(4);st.paragraph_format.line_spacing=1.07
 for name,sz,before,after,fg in [('Title',27,0,10,NAVY),('Heading 1',15.8,11,4,NAVY),('Heading 2',11.7,8,3,TEAL),('Subtitle',11.1,0,9,SOFT)]:
  s=d.styles[name];s.font.name='Aptos Display';s.font.size=Pt(sz);s.font.bold=name!='Subtitle';s.font.color.rgb=color(fg);s.paragraph_format.space_before=Pt(before);s.paragraph_format.space_after=Pt(after);s.paragraph_format.keep_with_next=True
 for name,sz,bold,fg in [('Micro',7.9,False,SOFT),('Small',8.3,False,INK),('Punch',11.2,True,TEAL)]:
  if name not in d.styles:s=d.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
  else:s=d.styles[name]
  s.font.name='Aptos';s.font.size=Pt(sz);s.font.bold=bold;s.font.color.rgb=color(fg);s.paragraph_format.space_after=Pt(3.5)
 h=sec.header.paragraphs[0];h.alignment=WD_ALIGN_PARAGRAPH.RIGHT;r=h.add_run('FROM INTENT TO EVIDENCE  /  ENGINEERING RESEARCH');r.font.size=Pt(7.2);r.font.color.rgb=color(SOFT)
 f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.RIGHT;r=f.add_run('SOURCE-BOUNDED  •  NOT A PRODUCT CERTIFICATE     ');r.font.size=Pt(7.2);r.font.color.rgb=color(SOFT)
 fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');f._p.append(fld)
 def p(text='',style=None,keep=False):
  q=d.add_paragraph(style=style);
  if text:q.add_run(text)
  q.paragraph_format.keep_together=keep
  return q
 def strong(lead,text):
  q=p();a=q.add_run(lead+'  ');a.bold=True;q.add_run(text);return q
 def h1(x):return d.add_heading(x,level=1)
 def h2(x):return d.add_heading(x,level=2)
 def fig(fname,caption,alt,width=16.3):
  q=p();q.alignment=WD_ALIGN_PARAGRAPH.CENTER;q.paragraph_format.space_before=Pt(6);q.paragraph_format.space_after=Pt(2)
  im=q.add_run().add_picture(str(ROOT/fname),width=Cm(width));im._inline.docPr.set('descr',alt)
  z=p(caption,style='Micro');z.alignment=WD_ALIGN_PARAGRAPH.CENTER
 def table(headers,rows,widths=None,fs=8.0):
  t=d.add_table(rows=1,cols=len(headers));t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER
  for k,title in enumerate(headers):
   cell=t.rows[0].cells[k];cell.text=str(title);shade(cell,NAVY)
   if widths:cell.width=Cm(widths[k])
   for para in cell.paragraphs:
    para.paragraph_format.space_after=Pt(1)
    for run in para.runs:run.bold=True;run.font.size=Pt(8);run.font.color.rgb=color(WHITE)
  headerrow(t.rows[0]);no_split(t.rows[0])
  for j,rowdata in enumerate(rows):
   row=t.add_row();no_split(row)
   for k,v in enumerate(rowdata):
    cell=row.cells[k];cell.text=str(v);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if widths:cell.width=Cm(widths[k])
    if j%2:shade(cell,'F4F7F8')
    for para in cell.paragraphs:
     para.paragraph_format.space_after=Pt(1);para.paragraph_format.space_before=Pt(1)
     for run in para.runs:
      run.font.size=Pt(fs);run.font.color.rgb=color(INK)
      if k==0:run.bold=True
  p('')
  return t
 def pg():d.add_page_break()

 # Cover and abstract, no edition identifiers
 p('ENGINEERING THE OBSERVER, NOT JUST WRITING A CHECKLIST',style='Micro')
 p('Build with AI.\nVerify before you trust.',style='Title')
 p('How an AI-assisted novice can direct a governed engineering process through contracts, reticula, falsification and accountable evidence.',style='Subtitle')
 p('The core idea',style='Heading 2')
 p('An AI can propose a design, inspect a local source tree, construct a bounded model of possible behavior and help implement a change. None of those actions automatically proves that the change works for real users, preserves security or deserves release. The proposed leverage is to let a less-specialised operator orchestrate the sequence while experienced reviewers retain final judgment. An explicit contract travels through source, executable observations, deliberate counterexamples and accountable decisions; whether this reduces total expertise and cost is a testable hypothesis.')
 fig('figure_contract.png','Figure 1. Each transition changes what may be claimed; evidence from a previous stage does not authorize the next.','Five blocks representing human outcome, contract, semantic reticulum, observation and accountable decision.')
 strong('What the reader receives.','An operational method; an example that begins with no software background; six product/software/repository assessments; 120 historical source-file references; a disciplined decision procedure for simplification; and a bounded adversarial-question framework.')
 strong('What this is not.','A certificate for six products, a demonstration of 120 successful test executions, a capacity benchmark, an independent security assessment, or proof that one method makes developers faster.')
 p('A productive human can ask for progress without personally knowing every technical step. The contract makes those steps criticisable; it does not replace expert acceptance.',style='Punch')

 h1('1  What the wider research trajectory teaches')
 p('A defensible reading of the research and software histories is a sequence of related engineering questions, not a claim of formal derivation. ROA (Reticular Observer Architectures) asks how an observer represents partial knowledge without hiding its limits. AOSP (Augmented Ontological-Semantic Platforms) names an ecosystem of platform concepts, implementations and knowledge-engineering experiments: it is not one product, runtime or repository. Particular A-OSP implementation lines explored durable source records, readback, lineage and replaceable model operations; those sources cannot establish properties of the entire ecosystem. The iKant line examines session states, replaceable computation, host permissions, action control and delivery evidence. The application repositories expose user, browser, storage, security and deployment counterexamples. CORA applies a related evidence discipline to source and repository assurance.')
 p('Names mark different abstraction and authority boundaries: ROA is a theoretical programme; AOSP denotes a wider ecosystem; a named implementation is a particular software system; CORA is an engineering method with a separately executable audit engine. This is a qualified conceptual mapping, not a certified ecosystem architecture. Some original repositories are private. It does not prove that theory generated each product, or that any implementation realizes the entire theory.')
 strong('Repeated, source-supportable pattern.','A discrepancy creates a more discriminating oracle: stale database evidence leads to restart/readback checks; an interface defect leads to DOM-hit or browser captures; cache failures lead to quota and revalidation tests; a moved file leads to consumer and Git-epoch checks. The relevant unit of learning is a failure → corrected hypothesis → source change → named test → remaining debt chain.')
 strong('What remains unknown.','The amount of human work, the independent quality of the resulting software, live service availability, safety in every relevant environment, and CORA’s incremental benefit over an equally informed strong checklist.')
 h2('The bryophyte: observer construction in a non-software domain')
 p('Annex B (August 2025) specifies a generalist bryophyte as a bounded computational scientific model with 20 abstraction levels, 42 measurable or normalized parameters, update rules, environmental forcing, thresholds and falsification criteria. The browser Bryophyte Epistemic Lab subsequently turns the model into an inspectable seeded simulator. This is a genuine source-level and implemented example of science treated as a typed, replayable observer; it does not establish ecological predictive validity.')
 p('The botanical exercise and CORA share a structural grammar: human question -> selected horizon -> provisional levels and variables -> operational rules -> simulation or runtime -> counterexamples -> explicit epistemic debt. The biology side models plant-state trajectories; the engineering side models conditions of software acceptance. This is a useful cross-domain analogy, NOT identical oracles, equivalent empirical confidence, or evidence that one framework mathematically derives the other.')
 p('The author can defensibly be described as a meta-observer who selected, organized and demanded connections between domain levels, potentially using AI to propose and refine specialist sub-models. Git authorship and the published annex cannot establish how much botanical expertise was personally held, how much was supplied by AI, or who validated each botanical premise. The genuine domain expert remains necessary to check botanical truth. This makes the novice-orchestrator hypothesis worth testing, not already proved.')
 strong('Scientific novelty ceiling.','A plausible research contribution is the explicitly governed construction of a bounded cross-disciplinary observer and its loss-aware transfer to software assurance. Claiming the first such biological simulation, a new theory of life, or a proven generalized Turing test would require an independent prior-art search, matched empirical datasets, blinded expert evaluation and simple-model baselines. The proposed real-versus-synthetic blind test remains outstanding.')
 rp=p('Primary original research: ',style='Micro')
 link(rp,'Bryophyte Annex B, exact PDF-born source','https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/annex-b-rla-biological-case-bryophyte.md')
 rp.add_run('  |  ')
 link(rp,'Simulator at exact Git commit b0dcda8','https://github.com/Luke883i/ROA/blob/b0dcda8bef8b6e34455d86907db56f29ead1c521/Reticular%20Local%20Abstraction%20RLA-CRC-ECNN/ROA%20Bryophyte%20Epistemic%20Lab/ROA_Bryophyte_Epistemic_Lab_v9.html')
 rp.add_run('  |  ')
 link(rp,'Laboratory protocol and empirical limitations','https://github.com/Luke883i/ROA/blob/b0dcda8bef8b6e34455d86907db56f29ead1c521/Reticular%20Local%20Abstraction%20RLA-CRC-ECNN/ROA%20Bryophyte%20Epistemic%20Lab/ROA_Bryophyte_Epistemic_Lab_README.md')


 h1('2  Build the engineering contract before the patch')
 p('Requirements engineering provides the starting discipline: elicit stakeholder outcomes, convert them into testable obligations, establish ownership and traceability, then revise when new evidence changes assumptions. ISO/IEC/IEEE 29148 describes requirements-engineering processes; ISO/IEC/IEEE 15288 frames life-cycle responsibilities; ISO/IEC 25010 organizes product-quality characteristics. NIST SP 800-160, SSDF, OWASP ASVS and SLSA add relevant security and provenance perspectives. These are comparison frameworks, not certifications attached to the projects.')
 for label,txt in [
 ('Outcome and horizon.','Name the person, desired result, time, environment, protected interest and what is outside present knowledge.'),
 ('Scope and authority.','Record repository and source revision, system entrypoints, owner, user/actor, consent or permission boundary, and human approver.'),
 ('Necessary known conditions.','Derive currently identifiable AND obligations. Each has a failure condition and a distinct owner; gaps remain UNKNOWN rather than being inferred away.'),
 ('Implementation and consumers.','Map active writers/readers, static and dynamic imports, host calls, generated receipts, external interfaces and rollback.'),
 ('Observation contract.','Specify original expected behavior, positive and negative cases, runner and environment; distinguish source code, test code, executed receipt and external acceptance.'),
 ('Decision and revision.','Define who may accept residual risk, when the roadmap reopens, and what evidence would refute the next claim.')]:strong(label,txt)
 p('A running example: a reporter can create a case, find it after restart, and cannot close somebody else’s case. A working form is only one projected observation: successful write, durable readback, access denial, traceable error and recoverable deployment are separate necessary conditions. The current set can expand when a new dependency or threat is discovered.')

 h1('3  The semantic reticulum is broader than a dependency graph')
 p('A dependency graph answers which component requires another. A typed semantic reticulum is the wider network in which goals, hypotheses, evidence, behavior, people, permissions, time, assumptions, failures and implementation artifacts are related. Its edges can mean “requires”, “owned by”, “observed by”, “contradicted by”, “valid for this revision” or “not yet observed”. The dependency graph is one useful projection. The term reticulum is used here operationally; no algebraic lattice structure or mathematical completeness theorem is claimed.')
 fig('figure_reticulum.png','Figure 2. The same claim can be viewed through dependency, evidence, authority and temporal projections.','Six typed nodes connected by labelled relations; the unknown-consumer node cannot be treated as a successful observation.')
 p('When a test fails, do not reflexively redraw everything. Identify the nearest falsified relation, ask whether the root cause is implementation, test oracle, environment, owner, source epoch or a missing dependency; repair the smallest affected subgraph; rerun the original native check and all mandatory ancestors. If the failure discloses a new relation or actor, revise the reticulum and the acceptance contract. A passing UI check cannot compensate for a failed authorization or restore obligation.')

 h2('What RLA, ECNN and ECU add — without claiming new mathematical proofs')
 p('Reticular Local Abstraction supplies a grammar of levels, typed transmissions and explicit information losses. Compact Reticular Computability differentiates a bounded computable operational envelope from stronger claims about emergent formal structure; neither is a theorem of correctness for these implementations. The ECNN approach generalizes the convolutional gesture to semantic fields without claiming that an LLM orchestration is an ordinary trained convolutional network. An Epistemic Computational Unit can emit structured candidate states such as ANSWER, UNKNOWN, CONTRADICTION, HORIZON_EXCEEDED or REVIEW_REQUIRED. Controlled reification matters: when a generated label becomes a risk object, source requirement or action entitlement, provenance and approval must follow it. These are conceptual research proposals, not validated universal laws.')
 rp=p('Source theory: ',style='Micro');link(rp,'RLA foundations','https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/annex-a-rla-crc-foundations.md');rp.add_run('  |  ');link(rp,'ECNN formalization','https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/annex-c-ecnn-formalisation.md');rp.add_run('  |  ');link(rp,'AI as Observer Compiler','https://github.com/Luke883i/ROA/blob/519a85bb15e8a964ce2f4d2cb6fdba44ab2382e7/Operation/corpus/text/observer-compiler-wolfram.md')

 h1('4  AI as local observer and abstraction builder')
 p('The agent may inspect the authorized checkout, map consumer relationships, classify observations, propose competing explanations, create testable levels and select informative experiments. An abstraction level is a controlled change of description: human experience and ethical acceptability → product behavior → state and data contract → interface/software → execution and artifacts → institutional authority. Each level has a different oracle. Aesthetic value, legal legitimacy, human understanding and organizational trust cannot be reduced to compilation or a green pipeline.')
 fig('figure_cartesian.png','Figure 3. Four reusable dimensions of a scenario model; the agent navigates bounded combinations rather than executing an unbounded universe.','Four columns labelled population, security, continuity and delivery, converging on selection of native tests.')
 table(['Area','Candidate Cartesian axes','Meaningful real-world test'],[
 ('Population and demand','Actors × sessions × arrival rate × devices × network','Measure load/latency/error envelope; NILO substitutes player/device/frame performance for multiuser throughput.'),
 ('Security and trust','Actor × operation × resource × origin × token state','Attempt forbidden actions and request forgery; inspect server-side authorization.'),
 ('Continuity and state','Write stage × failure × storage epoch × restart × recovery','Crash/restart on the original database, prove readback and restore.'),
 ('Delivery and experience','Source revision × build × host × browser × user journey','Replay exact asset/contract behavior; compare users’ experience independently.')],[3.45,7.0,6.2],fs=8.2)
 p('Example: five actor classes × four session states × six demand bands × four environments × three failure states yields 1,440 modeled combinations, before additional axes. Exhaustive cross-products quickly explode. The AI may enumerate a deterministic, seeded sample, prioritize risk boundaries and use covering arrays, but only target-native execution turns a scenario into a measured software observation. NIST’s combinatorial-testing research supports bounded interaction coverage; it does not license a universal PASS.')
 strong('Three different scaling operations.','Backward derivation scales the space of requirements and owners; physical mutations scale the discrimination of real checkers on disposable files; scenario saturation scales selected model configurations and fault families. Their denominators must never be added together.')
 p('A bounded saturation statement is possible when newly discovered material failure classes decline across disclosed samples, the model and seed are fixed, survivors remain visible and native regression paths still pass. It is not proof that no undiscovered failures exist.')

 h2('Methods: from blobbing to execution, never conflating the evidence classes')
 table(['Method','Operational action','Witness / defeat condition'],[
 ('Contract blobbing','Freeze requirements, ownership, environment and open debt as immutable source artifacts.','Original Git tree/commit identity; fail on unregistered changes.'),
 ('Container materialization','An authorized coding agent executes scripts against a named checkout inside an isolated runner.','Commands, inputs, exit status and source-epoch-aligned logs.'),
 ('Reverse derivation','Move from observable user result back to candidate AND obligations and responsible subsystems.','Counterexample to each mandatory leaf; unknown dependencies remain explicit.'),
 ('Reticular abstraction','Model typed levels for scientific, business, product, code and governance claims.','Loss/assumption metadata at every collapse between levels.'),
 ('Physical mutation','Edit a disposable original file, then execute the original oracle.','Baseline passes; mutant fails for the expected mechanism; restore afterward.'),
 ('Model saturation','Enumerate or sample a declared finite scenario product with an independent finite oracle.','Coverage, seed, survivor classes and limits; never universal correctness.'),
 ('Security challenge','Mutate permissions, origins, identity, request replay, malicious paths and secret visibility within safe local fixtures.','Denied operations stay denied; expected diagnostic error and safe recovery.'),
 ('Cryptographic integrity','SHA-256 the actual bytes, seal a manifest and verify provenance and issuer separately.','Any tamper mismatches; hash alone is not identity or semantic truth.'),
 ('Contraction','Retire duplicated responsibility only with complete consumer census and original behavior parity.','Original/target tests, rollback, unchanged authority and debt accounting.'),
 ('One-Run handoff','Bundle outputs, hashes, source epoch, gaps and next reversible action.','Reopen and independently replay; no hidden promotion to approval.')],[3.3,6.9,6.4],fs=7.4)
 p('For cryptographic assurance, distinguish four claims: (1) exact bytes via a checked SHA-256 digest; (2) Git graph and object identity, often based on repository object formats; (3) authenticated issuer and build chain via verified signatures/attestations, which are not automatically present; and (4) actual runtime and scientific truth, which neither hashes nor signatures certify. The threat model must include forged receipts, substituted ZIPs, stale source epochs, replay and unauthorized publication. Check that a trusted party signs exactly the tested artifact; do not equate a Git hash with identity attestation or encryption.')
 p('An AI may explore a Cartesian product of user roles and concurrency, authentication states and hostile inputs, fault/recovery transitions, browser/device configurations and build provenance. Finite model saturation tests the declared model; to claim capacity for 2,000 simultaneous users or robust security one still needs executable load, denial, authorization and environment-specific traces. Bounded pairwise or t-way selection may prioritize interactions, not excuse untested combinations.')

 h1('5  From zero: put CORA into a ChatGPT Project')
 p('The beginner path uses a GitHub repository containing the target application, a ChatGPT Project containing a canonical method prompt and a temporary source ZIP, and an authorized code runner when execution is needed. A ZIP lacks the complete Git object history: preserve the exact source commit separately. ChatGPT Project instructions guide discussion; attaching a ZIP does not run CORA. Connected GitHub read access does not authorize push or merge.')
 for lead,txt in [
 ('Step 1 — make the repository.','In GitHub create a repository for the application, add a README, and note its current commit identifier. Decide whether it can contain real or only synthetic data.'),
 ('Step 2 — prepare the Project.','Create a ChatGPT Project. Paste the canonical method prompt into Project instructions. Attach a verified temporary ZIP of the target source plus, if available, the current CORA source bundle. Record the Git commit and SHA-256 of each attached ZIP in the conversation.'),
 ('Step 3 — state the human outcome.','In plain language, describe the person, the desired action, the forbidden action, the data that must survive, and the deployment environment. The agent proposes a typed contract and marks unknowns.'),
 ('Step 4 — ask for one reversible slice.','Have the agent derive testable obligations backward, map active owners and consumers, propose at least two alternative explanations and a first PR-sized change. Review the plan before write actions.'),
 ('Step 5 — execute with permission.','A separate authorized coding tool or local runner edits, tests and commits. Ask it to replay native original tests and controlled mutants on the exact Git revision. Without a runner the status is NOT_RUN, not PASS.'),
 ('Step 6 — preserve the handoff.','Export a new temporary ZIP, source SHA, test receipts, surviving faults, unknown dependencies and next-step rationale. Reattach the verified bundle to the same Project for the next conversation. Do not treat a chat transcript or ZIP as signed release approval.')]:strong(lead,txt)
 h2('Copyable first Project instruction')
 q=p('“Act as a contract-first engineering analyst, not a release authority. Start from my observable user goal. Propose currently identifiable necessary requirements at human, product, subsystem, code and evidence levels; identify actors, owners, unknown consumers and risks. Map a typed semantic reticulum; for every material claim specify the expected observation, counterexample family, source revision and execution environment. Use bounded, repeatable model scenarios and physical mutations only in disposable copies. Never report a test as executed without a real receipt. Propose one reversible change and explain the next highest-value falsification. Keep approval with an authorized human.”',style='Small')
 q.paragraph_format.left_indent=Cm(.5);q.paragraph_format.right_indent=Cm(.5)
 strong('When CORA is available locally.','From an authorized checkout, install its declared Python package, run the CLI help, capture a source snapshot and verify the resulting Git ledger. Use One-Run only if the installed version documents that command. A Project prompt by itself cannot invoke the engine or certify a service.')

 h1('6  Filesystem size, actual cost and safe contraction')
 p('File counts describe a maintenance surface, not complexity in isolation. One file may contain a whole service, while a hundred small files may enforce valuable boundaries. The relevant cost is the number of independently maintained responsibilities, overlapping writers, ambiguous entrypoints, hidden consumers, duplicated test oracles, generated/handwritten disagreement and change-coupling across revisions. Historical source and proof receipts may be intentionally numerous and must not be deleted merely to improve a count.')
 table(['Repository','Files','Workflows','Size of tracked file blobs'],[(NAMES[r],f'{HEADS[r][1]:,}',str(HEADS[r][2]),f'{HEADS[r][3]/1e6:.2f} MB') for r in REPOS],[4,2.3,3,7.35])
 p('Counts reflect one selected public Git main tree per repository (17 November 2026). The byte figure sums the sizes of tracked file blobs; it excludes history, installed dependencies, runtime data and untracked outputs. No normalized enterprise complexity score or engineering-effort ranking follows from this table.')
 fig('figure_contraction.png','Figure 4. Any unresolved mandatory consumer blocks deletion; a successful topology change alone is not proof of parity.','Four preconditions for source contraction: measured duplicate cost, all consumers, original behavior parity and rollback.')
 for lead,txt in [
 ('1 — Define the cut.','Identify a duplicated responsibility or costly coupling; preserve explicit product and authority owners.'),
 ('2 — Census consumers.','Include imports, dynamic loaders, path resolution, workflow references, generated artifacts and external applications. Unknown remains UNKNOWN.'),
 ('3 — Establish old behavior.','Pin the original Git tree, native tests, source modes, expected receipts and target-host path before editing.'),
 ('4 — Migrate one slice.','Change one coherent owner, use temporary compatibility adapters where necessary, and keep rollback/recovery executable.'),
 ('5 — Challenge before acceptance.','Replay old and new native behavior, independent target expectations where available and physical negative cases. Measure net complexity and new evidence debt separately.'),
 ('6 — Decide by authority.','A qualified reviewer accepts the narrow outcome or reopens the roadmap; repository size alone can neither approve nor reject the migration.')]:strong(lead,txt)

 h1('7  What enterprise comparison does — and does not — mean')
 p('The comparator is a deliberately hypothetical, professionally operated software service: documented product scope; explicit access and change rights; security testing proportionate to threats; tested backup/recovery; repeatable builds; monitoring, incident response, independent review and an accountable release owner. It is not a claim that every item is legally required for every type of product. NILO, a single-player game, requires a different performance and customer-acceptance rubric from an institutional compliance service.')
 table(['Product','Current structural position','Better next proof than an arbitrary directory cut'],[
 ('ICTC','Selective convergence started; large browser/test and workflow surface','Role-denial, SQLite restart/readback, effective reviewer and production service gates.'),
 ('Teddy','Launch/behavior consolidation started; visual, model and hosted paths remain','Real provider and device/GPU performance, anti-forgery and human visual evaluation.'),
 ('LUMEN','Compact; no demonstrated global contraction need','Backup/restore, workload envelope, host/integration and real-device acceptance.'),
 ('NILO','Very small; no present system-wide contraction case','Playable scope, frame timing, access and independent player enjoyment.'),
 ('iKant_EDU','Major root-directory cut completed; consumer parity not closed','Dynamic/host consumer census, current and historical native gates, real host acceptance.'),
 ('CORA','Some integrated profiles/workflows; remaining duplication unmeasured','Module/command ownership, original-Git replay, independent baseline and human cost.')],[3.1,5.9,7.65],fs=8.0)
 p('All six branches were observed as not protected by GitHub’s branch-protection field at the inspected time. This is a governance observation, not proof that no other organization-level rules exist. Required branch checks, external reviewers and permission boundaries must be verified separately for a governed release.')

 h1('8  The falsifiable thesis')
 p('A review catalogue supplies 1,000 structured adversarial questions: four viewpoints (CTO, CIO, CISO and independent product reviewer) × five life-cycle stages × five evidence domains × ten fault perturbations. One hundred core questions are the distinct viewpoint–stage–domain combinations. These are generated inspection prompts, not 1,000 expert interviews, discovered vulnerabilities or observed executions. The companion register preserves every question and its unexecuted status.')
 p('The decisive hypothesis is broader than agent-versus-checklist. A checklist does not supply the expertise, tool access, execution capacity or dependency discovery needed to satisfy it. CORA may lower the expertise needed to ORCHESTRATE a development process: a non-programmer can provide a goal, prompt and source ZIP while an authorized agent constructs abstractions, proposes tests and runs a bounded coding loop. This must not be confused with eliminating the specialist knowledge required to approve security, science, product quality and legal risk.')
 p('Preregister a four-cell comparison under matched tasks and tool budgets: novice + capable agent + checklist; novice + agent + CORA method and prompt/ZIP; novice + agent + executable CORA; expert + agent + strong checklist. Independently score product acceptance, serious missed faults, operator intervention count, expert reviewer time, source complexity, total compute/runner cost, incident/rollback readiness, user comprehension and evidence quality. A method with more artifact volume but no material benefit is not high leverage. A null or negative result must survive the publication process.')
 p('The strongest original finding now defensible is a repeated pattern of source-local failure -> hypothesis revision -> new counterexample -> source repair -> narrower accepted claim across several domains, plus an executable bryophyte observer built from a published reticulum. It is neither universal science nor demonstrated causal uplift. The future frontier is prospective comparison where operator expertise is itself a controlled variable.')

 strong('A discriminating decision.','Release only the outcome actually observed at the named source revision and environment, with surviving failures and unknowns attached. Treat a green dashboard, a PDF, a test source and an actual user journey as different kinds of evidence.')
 p('A seven-part irreducible research agenda remains: novice leverage, observer fidelity, contract completeness within declared horizons, negative-oracle discrimination, source reproducibility, total human/compute cost and independent governance. The companion audit maps 100 unreviewed scientific challenge nodes and 10,000 author-scoped, seeded source-model mutations; these are NOT product executions or independent science.')
 # Evidence pages, 20 verified source pin records per repo / 5 per lens
 for repo in REPOS:
  case=PRODUCTS[repo];title=h1(NAMES[repo]+'  |  Product, software and repository');title.paragraph_format.page_break_before=True
  p(case['noun'].upper(),style='Micro')
  p('Software. '+case['architecture'],style='Small')
  p('Source-observed trajectory. '+case['observable'],style='Small')
  p('Against a hypothetical enterprise comparator. '+case['enterprise'],style='Small')
  p('Contraction judgment. '+case['contraction'],style='Small')
  p('Highest-value next falsifier. '+case['experiment'],style='Small')
  h2('Original Git witnesses: five per comparison lens')
  rows=[]
  for code in ['U','S','R','D']:
   rec=[x for x in EVIDENCE if x['repository']==repo and x['lens']==code]
   for ix,r in enumerate(rec):
    s=r['summary']
    if len(s)>63:s=s[:60].rsplit(' ',1)[0]+'…'
    rows.append((code, r['sha'][:9],s,r['url'],r['semantic_fit']))
  # Two balanced witness columns: ten selected source records each, fully linked.
  t=d.add_table(rows=1,cols=2);t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER
  for k,heading in enumerate(('U / S  ·  DEMAND AND SECURITY','R / D  ·  CONTINUITY AND DELIVERY')):
   c=t.rows[0].cells[k];c.text=heading;shade(c,NAVY);c.width=Cm(8.2)
   for para in c.paragraphs:
    para.paragraph_format.space_after=Pt(1)
    for rr in para.runs:rr.font.size=Pt(8);rr.font.bold=True;rr.font.color.rgb=color(WHITE)
  headerrow(t.rows[0]);no_split(t.rows[0])
  left=rows[:10];right=rows[10:]
  for j in range(10):
   r=t.add_row();no_split(r)
   if j%2:
    for c in r.cells:shade(c,'F4F8F9')
   for k,(code,oid,summary,url,fit) in enumerate((left[j],right[j])):
    cell=r.cells[k];cell.text='';cell.width=Cm(8.2)
    para=cell.paragraphs[0]
    para.paragraph_format.space_after=Pt(2);para.paragraph_format.space_before=Pt(2)
    para.paragraph_format.line_spacing=1.04
    lead=para.add_run(code+'  ');lead.font.bold=True;lead.font.size=Pt(7.5);lead.font.color.rgb=color(TEAL)
    link(para,oid,url)
    tail=para.add_run('  '+summary)
    tail.font.size=Pt(7.5);tail.font.color.rgb=color(INK)
  p('U = population, sessions and demand · S = security/trust · R = recovery/state · D = delivery/change/experience. The category is a research lens, not confirmation of a passing capacity or security check. The complete register retains full SHA, original file object ID, path and semantic-fit flags.',style='Micro')
  strong('Recorded main tree.','SHA '+HEADS[repo][0][:12]+'… · '+str(HEADS[repo][1])+' tracked files · '+str(HEADS[repo][2])+' workflows. A different timestamp or branch may change this inventory.')
 # Keep framework links with the last evidence page, rather than an isolated references-only leaf.
 h2('Engineering framework references')
 refp=p('Primary normative and methodological references: ',style='Micro')
 for i,(label,url) in enumerate(STANDARDS):
  if i:refp.add_run('  ·  ')
  link(refp,label,url)


 rp=p('Scientific case and security method: ',style='Micro')
 link(rp,'Bryophyte simulator pinned commit (August 2026)','https://github.com/Luke883i/ROA/commit/b0dcda8bef8b6e34455d86907db56f29ead1c521');rp.add_run('  ·  ')
 link(rp,'NIST combinatorial testing','https://www.nist.gov/programs-projects/combinatorial-testing');rp.add_run('  ·  ')
 link(rp,'OWASP ASVS','https://asvs.owasp.org/')

 core=d.core_properties;core.title='Build with AI. Verify before you trust.';core.subject='Novice engineering leverage, contract-based observer compilation, bryophyte case and source-bound evidence';core.author='';core.keywords='engineering contract; observable AI; bounded falsification; source provenance'
 d.save(DOC)
 # canonical OOXML members for repeatable hash without false timestamp drift
 raw=DOC.read_bytes();buf=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(raw),'r') as zi,zipfile.ZipFile(buf,'w') as zo:
  for name in zi.namelist():
   info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o600<<16;info.create_system=3
   zo.writestr(info,zi.read(name),compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
 DOC.write_bytes(buf.getvalue())
 print(json.dumps({'doc':str(DOC),'bytes':DOC.stat().st_size,'sha256':hashlib.sha256(DOC.read_bytes()).hexdigest(),'source_links':120,'figures':4,'evidence_pages':6,'paragraphs':len(d.paragraphs),'tables':len(d.tables)},indent=2))
ensure_doc()
