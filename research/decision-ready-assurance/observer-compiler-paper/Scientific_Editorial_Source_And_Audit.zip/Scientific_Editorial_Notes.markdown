# Scientific editorial closure — external audit notes

The reader artifact is `From_Intent_to_Evidence.docx`. Its own contents are independent from the history of edits and from this file; proof and acceptance are deliberately kept here.

## Status and boundaries

The paper uses established requirements engineering, systems modeling, change-impact analysis, software verification, security threat modelling, model-based test selection and provenance terminology **before** introducing ROA, RLA/ECNN, AOSP, iKant and CORA as local research/tool names. These are not asserted to be certified scientific theories or mandatory industry vocabulary.

The source corpus contains six application/repository cases (ICTC, Teddy, LUMEN, NILO, iKant_EDU, CORA). Exactly 20 selected historical Git paths per case are preserved in `Gold_Git_Witnesses_120.json`; three incremental commit/file OIDs per case appear in `Incremental_Git_Witnesses_18.json`. The 138 references are identifiers and inspection entrypoints, **not 138 successful runtime tests**. They do not attribute code authorship to AI.

Scientific boundaries: the bryophyte simulator's 20 levels and 42 variables are a bounded computational model. Blind real-versus-synthetic expert discrimination, causal competence reduction, security certification, independent native product QA and effective enterprise governance remain open. A good authored document or a deterministic source build cannot close these.

## Reproduce the exact Word

On an authorized local container with Python 3.11+ and `python-docx==1.2.0`, run:

```sh
python polish_paper.py
python audit_paper.py
python /home/oai/skills/docx/render_docx.py From_Intent_to_Evidence.docx --output_dir render
sha256sum From_Intent_to_Evidence.docx
```

The document ZIP is canonically serialized to make local rebuild independent of file timestamps. Source input and executable scripts are in the accompanying ZIP. `audit_paper.py` mutates 138 Git hyperlink targets, 20 scientific-claim text anchors and four figure-alt properties (162 distinct **physical DOCX copies**), and must reject all. It also produces ten altered creator-metadata copies and must accept all. These are bounded **author-defined editorial oracles**, not exploits, independent reviewers or product execution.

The automated Word accessibility audit and visual page-by-page review are distinct checks. The review notes or generation logs are not inserted into the paper.

## Publication gate

The paper can be circulated as an authored research candidate. Independent editorial/scientific peer review, domain validation, empirical comparative study, full native product execution and a human publication decision remain separate noncompensatory requirements in `Scientific_Editorial_DoD.json`.
