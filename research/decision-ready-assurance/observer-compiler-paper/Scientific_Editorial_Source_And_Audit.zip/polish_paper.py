#!/usr/bin/env python3
"""Portable, source-bounded editorial polish. Revision evidence stays outside Word."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_BREAK
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source_manuscript.docx'
OUT = ROOT / 'From_Intent_to_Evidence.docx'
NAVY = '0B1F3A'
TEAL = '16796E'
PALE = 'F5F8FA'


def change_literal_in_runs(doc, old: str, new: str) -> int:
    hits = 0
    # Includes hyperlink runs, caption/footer text and all table runs.
    for part in (doc.part, doc.sections[0].header.part, doc.sections[0].footer.part):
        for element in part.element.iter():
            if element.tag == qn('w:t') and element.text and old in element.text:
                n = element.text.count(old)
                element.text = element.text.replace(old, new)
                hits += n
    return hits


def shading(cell, fill: str):
    tcPr = cell._tc.get_or_add_tcPr()
    el = tcPr.find(qn('w:shd'))
    if el is None:
        el = OxmlElement('w:shd')
        tcPr.append(el)
    el.set(qn('w:fill'), fill)
    el.set(qn('w:val'), 'clear')


def style_claim_table(table, *, font_pt=9.0):
    for i, row in enumerate(table.rows):
        row.height = None
        for cell in row.cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            shading(cell, NAVY if i == 0 else (PALE if i % 2 == 0 else 'FFFFFF'))
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_before = Pt(0)
                paragraph.paragraph_format.space_after = Pt(1.4)
                for run in paragraph.runs:
                    run.font.size = Pt(font_pt)
                    if i == 0:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
                    else:
                        run.font.color.rgb = RGBColor(30, 47, 68)


def deterministic_zip(source_docx: Path, target: Path):
    # Normalize package metadata, not scientific claims or Word content.
    with ZipFile(source_docx) as zin:
        entries = {n: zin.read(n) for n in zin.namelist()}
    with ZipFile(target, 'w') as zout:
        for name in sorted(entries):
            z = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            z.compress_type = ZIP_DEFLATED
            z.create_system = 0
            z.external_attr = 0o600 << 16
            zout.writestr(z, entries[name], compress_type=ZIP_DEFLATED, compresslevel=9)


def main():
    doc = Document(SOURCE)
    patches = {
        'Primary original research:': 'Original repository sources:',
        'A-OSP runtime': 'aosp1 source experiment',
        'Published internal fixtures with 16/16 agreement for both a method and a strong checklist do not establish a causal advantage.':
        'In one author-selected retrospective comparison, CORA and a strong checklist both scored 16/16 on selected fixtures. That tie does not identify a causal advantage.',
        'The study records a hundred core combinations and one thousand generated questions; their value depends on external oracles and subsequent action.':
        'The associated research catalogue contains 100 structured combinations and 1,000 generated questions; they are proposed reviews, not executed tests, and require external oracles and follow-through.',
        'The 20 original historical records retain their four-lens stratification; three later witnesses are marked ADDED.':
        'Twenty historical witnesses retain their four-lens stratification; three additional observations are explicitly marked ADDED.'
    }
    patch_counts = {old: change_literal_in_runs(doc, old, new) for old, new in patches.items()}
    if any(v == 0 for v in patch_counts.values()):
        raise ValueError('not all editorial anchors were present: ' + str(patch_counts))
    # Align closing tables with the manuscript design system; avoid overloaded callouts.
    assert len(doc.tables) == 12
    style_claim_table(doc.tables[-2], font_pt=9.0)
    style_claim_table(doc.tables[-1], font_pt=8.75)
    conclusion = doc.add_paragraph(style='Punch')
    conclusion.add_run('Research position. ')
    conclusion.add_run('A persistent engineering contract and source-anchored verification may reduce the competence required to coordinate complex AI-assisted work. Whether this produces better outcomes per unit of human and computational effort remains an empirical question; provenance and mutation tests cannot substitute for domain truth or legitimate authorization.')
    doc.core_properties.title = 'From Intent to Evidence'
    doc.core_properties.subject = 'Contract-first AI-assisted engineering: bounded claims and testable hypotheses'
    doc.core_properties.keywords = 'requirements engineering; software assurance; provenance; human-AI collaboration'
    doc.core_properties.author = ''
    # Canonical OOXML zip metadata; ensures exact replay independent of local clock.
    with NamedTemporaryFile(suffix='.docx', delete=False) as temp:
        temp_name = temp.name
    try:
        doc.save(temp_name)
        deterministic_zip(Path(temp_name), OUT)
    finally:
        os.unlink(temp_name)
    print(json.dumps({'document': str(OUT), 'size': OUT.stat().st_size, 'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(), 'applied_patches': patch_counts}, indent=2))

if __name__ == '__main__':
    main()
