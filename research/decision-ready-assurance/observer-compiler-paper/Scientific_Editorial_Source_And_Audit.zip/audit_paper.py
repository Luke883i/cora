#!/usr/bin/env python3
"""Finite author-defined integrity oracle for the public manuscript, NOT product testing."""
from __future__ import annotations
from collections import Counter
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
from lxml import etree
from docx import Document
import hashlib, json

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'From_Intent_to_Evidence.docx'
GOLD=json.loads((ROOT/'Gold_Git_Witnesses_120.json').read_text())['selection']
EXTRA=json.loads((ROOT/'Incremental_Git_Witnesses_18.json').read_text())['items']
SOURCE_LINKS=sorted(set([x['url'] for x in GOLD] + [f'https://github.com/Luke883i/{x["repo"]}/blob/{x["sha"]}/{x["path"]}' for x in EXTRA]))
SELECT=[4,7,8,9,11,12,13,14,16,17,18,19,22,25,27,29,31,34,36,39]
NS={
'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
'pr':'http://schemas.openxmlformats.org/package/2006/relationships',
'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
'wp':'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
'dc':'http://purl.org/dc/elements/1.1/'
}

def parts(b:bytes)->dict[str,bytes]:
 with ZipFile(BytesIO(b)) as z: return {n:z.read(n) for n in z.namelist()}

def rezip(d:dict[str,bytes])->bytes:
 out=BytesIO()
 with ZipFile(out,'w') as z:
  for name in sorted(d):
   inf=ZipInfo(name,date_time=(1980,1,1,0,0,0));inf.compress_type=ZIP_DEFLATED
   z.writestr(inf,d[name],compress_type=ZIP_DEFLATED,compresslevel=9)
 return out.getvalue()

def doc_content(b:bytes):
 d=Document(BytesIO(b))
 para=[p.text for p in d.paragraphs]
 rels=[r.target_ref for r in d.part.rels.values() if r.reltype.endswith('/hyperlink')]
 body_text=' '.join(para)+ ' '.join(c.text for t in d.tables for row in t.rows for c in row.cells)
 descr=[]
 for el in d.part.element.findall('.//{'+NS['wp']+'}docPr'):
  descr.append(el.get('descr',''))
 return para,rels,body_text,d,descr

def baseline_anchors(original):
 para,_,_,_,_=doc_content(original)
 doc=etree.fromstring(parts(original)['word/document.xml'])
 main=doc.find('.//{'+NS['w']+'}body')
 pp=main.findall('./{'+NS['w']+'}p')
 assert len(pp)==len(para)
 anchors=[]
 for ix in SELECT:
  values=[(el.text or '') for el in pp[ix].findall('.//{'+NS['w']+'}t')]
  line=max(values,key=len)
  if len(line)<50:raise ValueError('Anchor too short at '+str(ix))
  anchors.append((ix,line[:74]))
 return anchors

def evaluate(b,anchors):
 problems=[]
 try:
  para,links,text,d,descr=doc_content(b)
 except Exception as e: return ['DOCUMENT_OPEN_FAILED_'+type(e).__name__]
 git=[u for u in links if 'github.com/' in u and '/blob/' in u]
 if len(SOURCE_LINKS)!=138 or len(GOLD)!=120 or len(EXTRA)!=18:problems.append('REGISTER_SIZE')
 if not set(SOURCE_LINKS).issubset(set(links)):problems.append('GIT_SOURCE_REFERENCE_LOSS')
 if len(d.inline_shapes)!=4 or len(descr)!=4 or not all(len(x)>20 for x in descr):problems.append('ACCESSIBLE_DIAGRAM_LOSS')
 if len(d.tables)!=12:problems.append('TABLE_STRUCTURE_LOSS')
 if len(para)<155:problems.append('MANUSCRIPT_STRUCTURE_LOSS')
 for i,anchor in anchors:
  if not any(anchor in s for s in para):problems.append('SCIENTIFIC_CLAIM_ANCHOR_'+str(i))
 required=['The claim in conventional engineering terms','1  The conventional engineering problem',
 '2  Requirements, interfaces and acceptance criteria','3  From traceability to a typed evidence model',
 'Local terminology introduced after the conventional model','AOSP denotes the Augmented Ontological-Semantic Platforms ecosystem',
 'That tie does not identify a causal advantage','What the evidence permits','Open hypotheses with possible discriminating tests',
 'Classes of AI-assisted semantic work','Research position.']
 for token in required:
  if token not in text:problems.append('READER_CONTRACT_'+token[:25])
 for forbidden in ('A-OSP runtime','Primary original research:', 'academics','all indispensable conditions','independent counterexamples'):
  if forbidden.lower() in text.lower():problems.append('INFLATED_OR_STALE_TERMINOLOGY_'+forbidden)
 first=next(i for i,p in enumerate(para) if p.startswith('Local terminology introduced'))
 foundation=next(i for i,p in enumerate(para) if p.startswith('1  The conventional engineering problem'))
 requirements=next(i for i,p in enumerate(para) if p.startswith('2  Requirements'))
 if not (foundation < requirements < first):problems.append('TAXONOMY_BEFORE_SCIENCE')
 if any('semantic reticulum' in p.lower() for p in para[:first]):problems.append('LOCAL_LANGUAGE_PREMATURE')
 return sorted(set(problems))

def main():
 original=OUT.read_bytes();dparts=parts(original);anchors=baseline_anchors(original)
 defects=evaluate(original,anchors)
 assert not defects,defects
 results=[]; digests=[]
 def record(label,updated,expect_reject):
  raw=rezip(updated);digest=hashlib.sha256(raw).hexdigest();digests.append(digest)
  problems=evaluate(raw,anchors)
  verdict=bool(problems)
  results.append({'id':label,'expected_reject':expect_reject,'rejected':verdict,'first_finding':problems[0] if problems else None,'sha256':digest})
  if verdict != expect_reject: raise AssertionError((label,problems))
 # 138 exact historical source reference mutants: physically change a ZIP relationship target.
 for i,url in enumerate(SOURCE_LINKS,1):
  q=dparts.copy();rels=etree.fromstring(q['word/_rels/document.xml.rels']);hits=0
  for rel in rels:
   if rel.get('Target')==url:
    rel.set('Target',url.replace('github.com','untrusted.example.invalid',1));hits+=1
  if hits!=1:raise ValueError('not exactly one Git relation '+url)
  q['word/_rels/document.xml.rels']=etree.tostring(rels,encoding='UTF-8',xml_declaration=True)
  record('SOURCE_'+str(i).zfill(3),q,True)
 # 20 factual/epistemic paragraph mutations, at precisely identified original w:t elements.
 for i,(index,anchor) in enumerate(anchors,1):
  q=dparts.copy();xml=etree.fromstring(q['word/document.xml']);body=xml.find('.//{'+NS['w']+'}body')
  pp=body.findall('./{'+NS['w']+'}p');hits=0
  for el in pp[index].findall('.//{'+NS['w']+'}t'):
   if el.text and anchor in el.text:
    el.text=el.text.replace(anchor,'[claim omitted in mutant]',1);hits+=1
  if hits!=1:raise ValueError('wrong text mutation match at '+str(index))
  q['word/document.xml']=etree.tostring(xml,encoding='UTF-8',xml_declaration=True)
  record('CLAIM_'+str(i).zfill(2),q,True)
 # 4 physically corrupted alt texts, all expected rejected.
 for i in range(4):
  q=dparts.copy();xml=etree.fromstring(q['word/document.xml'])
  tags=xml.findall('.//{'+NS['wp']+'}docPr');assert len(tags)==4
  tags[i].set('descr','')
  q['word/document.xml']=etree.tostring(xml,encoding='UTF-8',xml_declaration=True)
  record('FIGURE_ALT_'+str(i+1),q,True)
 # 10 benign changes to non-semantic creator metadata MUST NOT be rejected.
 for i in range(10):
  q=dparts.copy(); xml=etree.fromstring(q['docProps/core.xml'])
  nodes=xml.findall('.//{'+NS['dc']+'}creator')
  if len(nodes)!=1:raise ValueError('core metadata schema changed')
  nodes[0].text=f'local-neutral-reviewer-{i:02d}'
  q['docProps/core.xml']=etree.tostring(xml,encoding='UTF-8',xml_declaration=True)
  record('BENIGN_METADATA_'+str(i+1),q,False)
 assert len(set(digests))==len(digests)
 from collections import Counter
 groups=Counter('BENIGN' if x['id'].startswith('BENIGN') else x['id'].split('_')[0] for x in results)
 report={
  'schema':'scientific-word-exact-source-falsification/1',
  'scope':'AUTHOR_DEFINED_DOCUMENT_AND_SOURCE_REFERENCES_ONLY',
  'word_sha256':hashlib.sha256(original).hexdigest(),
  'word_bytes':len(original),
  'original_git_witnesses':138,
  'historical_source_pins':120,
  'new_git_commit_file_oid_pins':18,
  'source_links_visible':138,
  'descriptive_diagrams':4,
  'pages_rendered_separately':14,
  'critical_semantic_anchors':len(anchors),
  'negative_physical_docx_mutations':sum(x['expected_reject'] for x in results),
  'negatives_rejected':sum(x['expected_reject'] and x['rejected'] for x in results),
  'benign_physical_docx_mutations':sum(not x['expected_reject'] for x in results),
  'benign_accepted':sum(not x['expected_reject'] and not x['rejected'] for x in results),
  'fault_families':dict(groups),
  'survivors':[x['id'] for x in results if x['expected_reject'] and not x['rejected']],
  'false_positives':[x['id'] for x in results if not x['expected_reject'] and x['rejected']],
  'product_runtimes':'NOT_EXECUTED',
  'independent_review':'NOT_ATTESTED',
  'ai_authorship':'UNATTRIBUTABLE_FROM_GIT',
  'causal_skill_reduction':'NOT_ESTABLISHED',
  'claim_level':'PASS_AUTHOR_SCOPED_DOCUMENT_INTEGRITY',
 }
 (ROOT/'Paper_Adversarial_Audit.json').write_text(json.dumps({**report,'cases':results},indent=2)+'\n')
 print(json.dumps(report,indent=2))

if __name__=='__main__':main()
